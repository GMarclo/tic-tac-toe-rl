import torch
from board import TicTacToe
from agent import Agent


def play():
    game = TicTacToe()
    agent = Agent()

    # Wczytanie mózgu i wyłączenie losowości
    agent.model.load("models/tictactoe_net.pth")
    agent.model.eval()  # Ustawiamy sieć w tryb przewidywania
    agent.epsilon = 0  # 0% losowości - gramy na poważnie

    print("Witaj w grze z AI!")
    user_starts = input("Chcesz zacząć jako X (1) czy O (2)? [1/2]: ") == "1"

    # Przypisanie ról
    user_player = 1 if user_starts else -1
    ai_player = user_player * -1

    while not game.game_over:
        print("\n" + str(game))
        valid_moves = game.get_valid_moves()

        if game.current_player == user_player:
            # RUCH GRACZA (CIEBIE)
            print(f"Twoje legalne ruchy to: {valid_moves}")
            try:
                move = int(input("Wybierz pole (0-8): "))
                if move not in valid_moves:
                    print("Nielegalny ruch, spróbuj ponownie.")
                    continue
            except ValueError:
                print("Wpisz poprawną liczbę!")
                continue
        else:
            # RUCH AI
            print("AI myśli...")
            # Pamiętaj o KANONICZNEJ PLANSZY!
            # Sieć widzi planszę ze swojej perspektywy (ai_player)
            canonical_state = agent.get_state(game).copy() * ai_player

            # Sieć wybiera ruch
            move = agent.get_action(canonical_state, valid_moves)
            print(f"AI wybiera pole: {move}")

        # Wykonanie ruchu na prawdziwej planszy
        game.step(move)

    # Koniec gry
    print("\n" + str(game))
    if game.check_win():
        # current_player zmienił się po ostatnim ruchu, więc wygrał ten poprzedni
        if game.current_player == user_player:
            print("🎉 Wygrałeś z AI! (Zwiększ liczbę gier w treningu!)")
        else:
            print("🤖 AI wygrało! Zostałeś pokonany przez własny twór.")
    else:
        print("🤝 Remis! (Dobra sieć w kółko i krzyżyk zawsze remisuje).")


if __name__ == "__main__":
    play()
